
var total=document.getElementById("total");


function j1total(){
	var j1=document.getElementById("j1").value;
	document.getElementById("j1price").innerHTML="$"+j1*4350;
	total.innerHTML="$"+j1*4350;
}

function j2total(){
	var j2=document.getElementById("j2").value;
	document.getElementById("j2price").innerHTML="$"+j2*3400;
}


function j3total(){
	var j3=document.getElementById("j3").value;
	document.getElementById("j3price").innerHTML="$"+j3*4550;
}

function j4total(){
	var j4=document.getElementById("j4").value;
	document.getElementById("j4price").innerHTML="$"+j4*6150;
}

function j5total(){
	var j5=document.getElementById("j5").value;
	document.getElementById("j5price").innerHTML="$"+j5*6150;
}

function j6total(){
	var j6=document.getElementById("j6").value;
	document.getElementById("j6price").innerHTML="$"+j6*1420;
}

function j7total(){
	var j7=document.getElementById("j7").value;
	document.getElementById("j7price").innerHTML="$"+j7*5100;
}

function j8total(){
	var j8=document.getElementById("j8").value;
	document.getElementById("j8price").innerHTML="$"+j8*1890;
}

function j9total(){
	var j9=document.getElementById("j9").value;
	var jt9=document.getElementById("j9price").innerHTML="$"+j9*4800;
}

var total=document.getElementById("total");

total.innerHTML=jt9;