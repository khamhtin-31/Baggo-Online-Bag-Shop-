document.addEventListener('DOMContentLoaded', function () {
    var viewIcon = document.getElementsByClassName('fas fa-eye');
    var enlarged = document.getElementsByClassName('img-fluid');

    // Show the enlarged image container
    viewIcon.addEventListener('click', function () {
 enlarged.style.width="600px";
 enlarged.style.height="auto";
 enlarged.style.transition="width 0.5s ease-in";
    });
}
    